#include "Due�o.h"
#include <string>

void Due�o::registrarDue�o(std::string nombre, std::string ID) {
	this->nombre = nombre;
	this->ID = ID;
}

std::string Due�o::getNombre() { return nombre; }
int Due�o::getContadorMascotas() { return contadorMascotas; }
int Due�o::getContadorGastos() { return contadorGastos; }