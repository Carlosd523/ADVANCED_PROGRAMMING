#pragma once
#ifndef GASTO_H
#define GASTO_H

#include <string>
#include "Mascota.h"
#include "Due�o.h"

using namespace std;

class Gasto
{
private:
	Mascota mascota;
	Due�o& dueno;
	string fecha;
	double costoUnidad;
	int unidades;
	string descripcion;
public:
	// Constructor por defecto
	Gasto() {}

	// Constructor con par�metros
	void registrarGasto(Mascota mascota, Due�o dueno, string fecha, double costoUnidad, int unidades, string descripcion) {}

	void detallesGasto() {}
	string getDescripcion() {}
	~Gasto() {}
};

#endif