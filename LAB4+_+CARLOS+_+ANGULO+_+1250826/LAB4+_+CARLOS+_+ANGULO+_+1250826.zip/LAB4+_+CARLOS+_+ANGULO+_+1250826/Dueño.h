#pragma once
#ifndef DUENO_H
#define DUENO_H

#include <string>
#include "Mascota.h"
#include "Gasto.h"

using namespace std;

class Gasto;

struct Due�o
{
	string nombre;
	string ID;
	Mascota mascotas[10];
	int contadorMascotas = 0;
	Gasto gastos[20];
	int contadorGastos = 0;

	Due�o() {};

	void registrarDue�o(string nombre, string ID) {}

	string getNombre();
	int getContadorMascotas();
	int getContadorGastos();

	~Due�o() {};
};

#endif