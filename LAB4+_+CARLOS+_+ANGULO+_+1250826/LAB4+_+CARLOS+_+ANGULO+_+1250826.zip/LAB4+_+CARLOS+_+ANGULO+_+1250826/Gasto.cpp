#include "Gasto.h"
#include <iostream>
#include <string>
using namespace std;

void Gasto::registrarGasto(Mascota mascota, Due�o dueno, string fecha, double costoUnidad, int unidades, string descripcion) {
	this->mascota = mascota;
	this->dueno = dueno;
	this->fecha = fecha;
	this->costoUnidad = costoUnidad;
	this->unidades = unidades;
	this->descripcion = descripcion;
}

void Gasto::detallesGasto() {
	cout << "Due�o: " << dueno.getNombre()
		<< "Mascota: " << mascota.getNombre()
		<< "Fecha: " << fecha
		<< "Costo por unidad: " << costoUnidad
		<< "Unidades: " << unidades
		<< "Descripci�n: " << descripcion << endl;
}

string Gasto::getDescripcion() { return descripcion; }