#pragma once
#include <string>
#ifndef MASCOTA_H
#define MASCOTA_H

struct Mascota
{
	std:: string nombre;
	int tipo;
	bool datoEspecifico = false;
	double gastoMascota = 0;

	void funcionExtra() {}

	Mascota() {}

	void registrarMascota(std::string nombre, int tipo) {}

	string getNombre() {}

	double gastoTotalMascota() {}

	~Mascota() {}
};

#endif