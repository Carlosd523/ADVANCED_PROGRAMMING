#pragma once
#pragma once
#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <iostream>
#include <string>
#include "Excepciones.h"
#include "Gestor.h"

using namespace std;

// Funci�n 01 - Validar la entrada de un dato tipo int.
void validacionInt(int& num, int min, int max);

// Funci�n 02 - Limpiar la pantalla.
void limpiarPantalla();

// Funci�n 03 - Men�
void menu();

// Funci�n 04 - Men� tareas
void menuTareas(Gestor& gestor);

// Funci�n 05 - Men� actividades
void menuActividades(Gestor& gestor);

// Funciones ListaTareas
// Funci�n LT.1 - Agregar una tarea
void agregarTarea(Gestor& gestor);

// Funci�n LT.2 - Eliminar una tarea por Nombre
void eliminarTarea(Gestor& gestor);

// Funci�n LT.3 - Buscar una tarea
void buscarTarea(Gestor& gestor);

// Funci�n LT.4 - Mostrar las tareas
void mostrarTodasTareas(Gestor& gestor);

// Funci�n LT.5 - Mostrar las tareas inversamente
void mostrarTodasTareasInversamente(Gestor& gestor);

// Funci�n Validaci�n LT.1 - Valida que el nombre de la tarea sea v�lido
bool validacionNombre(Gestor& gestor, string nombre);

// Funciones RelojActividades
// Funci�n RA.1 - Agregar actividad
void agregarActividad(Gestor& gestor);

// Funci�n RA.2 - Eliminar actividad por hora
void eliminarActividad(Gestor& gestor);

// Funci�n RA.3 - Mostrar Actividad actual
void mostrarActividadActual(Gestor& gestor);

// Funci�n RA.4 - Avanzar al siguiente bloque horario
void avanzarBloqueHorario(Gestor& gestor);

// Funci�n RA.5 - Retroceder bloque horario
void retrocederBloqueHorario(Gestor& gestor);

// Funci�n RA.6 - Recorrer actividades
void recorrerActividades(Gestor& gestor);

// Funci�n Validaci�n RA.1 - Valida que la hora de la tarea sea v�lida
bool validacionHora(Gestor& gestor, int hora);

#endif