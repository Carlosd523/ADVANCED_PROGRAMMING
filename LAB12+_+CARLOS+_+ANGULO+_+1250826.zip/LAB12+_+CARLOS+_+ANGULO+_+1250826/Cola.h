#pragma once
#ifndef COLA_H
#define COLA_H
#include "NodoCricular.h"

class Cola
{
private:
	NodoCircular* frente = nullptr;
	NodoCircular* final = nullptr;
public:
	// Enqueue - Agrega un elemento a la cola
	void enqueue(TrabajoImpresion trabajo);

	// Dequeue - Elimina un elemento de la cola
	void dequeue();

	// Front - Muestra la informaci�n del trabajo que se encuentra en el frente
	TrabajoImpresion front() const;

	// IsEmpty - Determina si la cola est� vac�a
	bool isEmpty();

	// Destructor
	~Cola();
};

#endif