#pragma once
#ifndef FUNCIONES_H
#define FUNCIONES_H
#include "Gestor.h"

// Funci�n 01 - Validar la entrada de un dato tipo int.
void validacionInt(int& num, int min, int max);

// Funci�n 02 - Limpiar la pantalla.
void limpiarPantalla();

// Funci�n 03 - Validaci�n decimales
double validacionDouble(double& numero, double min, double max);

// Men�
void menu();

// Men� - Ejercicio pilas
void menuPilas(Gestor& gestor);

// Funci�n P.1 - Visita una p�gina nueva
void nuevaPagina(Gestor& gestor, string*& actual);

// Funci�n P.2 - Retrocede a la anterior p�gina
void retroceder(Gestor& gestor, string*& actual);

// Funci�n P.3 - Avanza a la siguiente p�gina
void avanzar(Gestor& gestor, string*& actual);

// Funci�n P.4 - Muestra el estado actual
void estadoActual(Gestor& gestor, string*& actual);

// Ejercicio Colas
void ejercicioCola(Gestor& gestor);


#endif