#include "Excepciones.h"

IndiceInvalido::IndiceInvalido(int indice) {
	mensaje = "No hay ning�n elemento en la posici�n " + to_string(indice) + ".";
}

const char* IndiceInvalido::what() const noexcept {
	return mensaje.c_str();
}

DatoFueraDelRango::DatoFueraDelRango(double dato, double min, double max) {
	mensaje = "El dato proporcionado est� afuera del rango. Rango actual: (" + to_string(min) + ", " + to_string(max)
		+ "). Dato actual: " + to_string(dato);
}

const char* DatoFueraDelRango::what() const noexcept {
	return mensaje.c_str();
}

DatoInvalido::DatoInvalido() {
	mensaje = "El dato proporcionado es un string y solamente se permiten n�meros";
}

const char* DatoInvalido::what() const noexcept {
	return mensaje.c_str();
}