#pragma once
#ifndef PILA_H
#define PILA_H
#include <string>
#include "Nodo.h"

using namespace std;

class Pila
{
private:
	Nodo* cima = nullptr;

public:
	// Constructor
	Pila();

	// M�todos
	// Push - Agrega un elemento a la pila
	void push(string pagina);

	// Pop - Elimina un elemento de la pila
	void pop();

	// Top - Devuelve la p�gina web que se encuentra en el tope de la pila
	string top();

	// IsEmpty - Retorna false si la pila tiene alg�n elemento, retorna true si la pila no tiene ning�n elemento
	bool isEmpty();

	// Mostrar - Muestra todos los elementos de la pila
	void mostrar() const;

	// Destructor
	~Pila();
};

#endif