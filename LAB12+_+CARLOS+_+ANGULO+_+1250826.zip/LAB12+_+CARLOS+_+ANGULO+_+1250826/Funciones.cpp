#include <iostream>
#include "Funciones.h"
#include "Excepciones.h"
#include <limits>

// Funci�n 01 - Valida la entrada de un dato tipo int.
void validacionInt(int& num, int min, int max) {
	bool validacion = false;
	do {
		try {
			cin >> num;
			if (cin.fail()) {
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				throw DatoInvalido();
			}
			else if (num < min || num > max) {
				throw DatoFueraDelRango(num, min, max);
			}
			else {
				validacion = true;
			}
		}
		catch (DatoInvalido& e) {
			cout << e.what() << endl;
			cout << "Intente nuevamente: ";
		}
		catch (DatoFueraDelRango& e) {
			cout << e.what() << endl;
			cout << "Intente nuevamente: ";
		}
	} while (!validacion);
}

// Funci�n 02 - Limpia la pantalla.
void limpiarPantalla() {
	cout << "Presione Enter para continuar...";
	cin.clear();
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
	cin.get();

	system("cls");
}

// Funci�n 03 - Validaci�n decimales
double validacionDouble(double& numero, double min, double max) {
	bool valido = false;
	do {
		try {
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cin >> numero;
			if (cin.fail()) {
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				throw invalid_argument("Error: Ingrese un n�mero v�lido (decimal permitido)");
			}
			else if (numero < min || numero > max) {
				throw out_of_range("Error: El n�mero ingresado est� fuera del rango permitido");
			}
			valido = true;
		}
		catch (const exception& e) {
			cout << e.what() << endl;
			cout << "Intente nuevamente: ";
			valido = false;
		}
	} while (!valido);
	return numero;
}

// Men�
void menu() {
	int optMenuP;
	Gestor gestor;

	// Arreglo de punteros a funciones
	void (*menuP[2])(Gestor & gestor) = {
		&menuPilas,
		&ejercicioCola
	};

	do {
		cout << "�Qu� ejercicio desea realizar?"
			<< "\n1. Ejercicio 1"
			<< "\n2. Ejercicio 2"
			<< "\n3. Salir" << endl;
		cout << "Ingrese la opci�n que desea realizar: ";
		validacionInt(optMenuP, 1, 3);
		limpiarPantalla();
		if (optMenuP != 3) { (*menuP[optMenuP - 1])(gestor); }
		limpiarPantalla();
	} while (optMenuP != 3);
}

// Men� - Ejercicio pilas
void menuPilas(Gestor& gestor) {
	int optMenu;
	string* actual = new string();

	// Arreglo de punteros a funciones
	void (*menuP[4])(Gestor& gestor, string*& actual) = {
		&nuevaPagina,
		&retroceder,
		&avanzar,
		&estadoActual
	};


	do {
		cout << "Bienvenido al navegador web ANGULO" << endl;
		cout << "�Qu� desea hacer?"
			<< "\n1. Ingresar a una nueva p�gina"
			<< "\n2. Retroceder"
			<< "\n3. Avanzar"
			<< "\n4. Mostrar el estado actual"
			<< "\n5. Salir" << endl;
		cout << "Ingrese la opci�n que desea realizar: ";
		validacionInt(optMenu, 1, 5);
		limpiarPantalla();
		if (optMenu != 5) {
			(*menuP[optMenu - 1])(gestor, actual);
			if (!actual->empty()) {
				cout << endl;
				cout << "P�gina actual: " << *actual << endl;
			}
		}
		limpiarPantalla();
	} while (optMenu != 5);

	delete actual;
}

// Funci�n P.1 - Visita una p�gina nueva
void nuevaPagina(Gestor& gestor, string*& actual) {
	string nuevaPagina;
	cout << "=============== NUEVA P�GINA ===============" << endl;
	cout << "Ingrese la p�gina a la que desea acceder: ";
	cin >> nuevaPagina;

	if (!actual->empty()) {
		gestor.paginasAnteriores.push(*actual);
	}
	
	while (!gestor.paginasSiguientes.isEmpty()) {
		gestor.paginasSiguientes.pop();
	}

	*actual = nuevaPagina;
}

// Funci�n P.2 - Retrocede a la anterior p�gina
void retroceder(Gestor& gestor, string*& actual) {
	cout << "=============== RETROCEDER ===============" << endl;
	if (gestor.paginasAnteriores.isEmpty()) {
		cout << "No hay p�ginas anteriores" << endl;
		return;
	}

	gestor.paginasSiguientes.push(*actual);
	*actual = gestor.paginasAnteriores.top();
	gestor.paginasAnteriores.pop();
	cout << "Se retrocedi� exitosamente" << endl;
}

// Funci�n P.3 - Avanza a la siguiente p�gina
void avanzar(Gestor& gestor, string*& actual) {
	cout << "=============== AVANZAR ===============" << endl;
	if (gestor.paginasSiguientes.isEmpty()) {
		cout << "No hay p�ginas siguientes" << endl;
		return;
	}

	gestor.paginasAnteriores.push(*actual);
	*actual = gestor.paginasSiguientes.top();
	gestor.paginasSiguientes.pop();
	cout << "Se avanz� exitosamente" << endl;
}

// Funci�n P.4 - Muestra el estado actua�
void estadoActual(Gestor& gestor, string*& actual) {
	cout << "=============== ESTADO ACTUAL ===============" << endl;
	cout << "P�ginas siguientes" << endl;
	if (gestor.paginasSiguientes.isEmpty()) {
		cout << "No hay p�ginas siguientes" << endl;
	}
	else {
		gestor.paginasSiguientes.mostrar();
	}
	cout << endl;

	cout << "P�gina actual" << endl;
	if (actual->empty()) {
		cout << "No se ha ingresado a ninguna p�gina" << endl;
	}
	else {
		cout << *actual << endl;
	}
	cout << endl;

	cout << "P�ginas anteriores" << endl;
	if (gestor.paginasAnteriores.isEmpty()) {
		cout << "No hay p�ginas anteriores" << endl;
	}
	else {
		gestor.paginasAnteriores.mostrar();
	}
}

// Ejercicio Colas
void ejercicioCola(Gestor& gestor) {
	int cantTrabajos, numeroPags, contador = 0, cantPaginas = 0;
	double vImpresion, tiempoTranscurrido = 0;
	string nombreDocumento;

	cout << "=============== EJERCICIO COLA ===============" << endl;
	cout << "Ingrese la cantidad de trabajos que la impresora deber� imprimir: ";
	validacionInt(cantTrabajos, 1, 100);

	cout << "Ingrese la velocidad de la impreosa en segundos por p�gina: ";
	validacionDouble(vImpresion, 0.1, 10);
	limpiarPantalla();

	cin.ignore(numeric_limits<streamsize>::max(), '\n');
	for (int i = 0; i < cantTrabajos; i++) {
		cout << "Ingrese el nombre del documento: ";
		getline(cin, nombreDocumento);

		cout << "Ingrese el n�mero de p�ginas: ";
		validacionInt(numeroPags, 1, 100);
		contador++;

		TrabajoImpresion nuevoTrabajo = TrabajoImpresion(contador, nombreDocumento, numeroPags);
		gestor.cola.enqueue(nuevoTrabajo);
		limpiarPantalla();
	}

	while (!gestor.cola.isEmpty()) {
		TrabajoImpresion trabajo = gestor.cola.front();
		double tiempoImpresion = trabajo.numeroPaginas * vImpresion;
		gestor.cola.dequeue();

		cout << "Imprimiendo trabajo #" << trabajo.idTrabajo << "(" << trabajo.numeroPaginas << " p�ginas, " << tiempoImpresion << " segundos)" << endl;
		cout << endl;

		tiempoTranscurrido += tiempoImpresion;
		cantPaginas += trabajo.numeroPaginas;
	}

	cout << "Tiempo total de impresi�n: " << tiempoTranscurrido
		<< "\nTotal p�ginas impresas: " << cantPaginas << endl;
	limpiarPantalla();
}